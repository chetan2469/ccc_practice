import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MobileAuth extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _MobileAuth();
  }
}

class _MobileAuth extends State<MobileAuth> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      body: Center(
          child: Column(
        children: <Widget>[
          Container(
              child: TextField(
            onChanged: (value) {},
            decoration: InputDecoration(hintText: "Enter Your Mobile Number"),
          )),
          RaisedButton(
            child: Text("verify"),
            onPressed: () {},
          ),
          RaisedButton(
            child: Text("back"),
            onPressed: () {},
          )
        ],
      )),
    );
  }
}
