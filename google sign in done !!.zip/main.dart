import 'package:flutter/material.dart';
import 'homePage.dart';

void main() => runApp(new MyApp());

class MyApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _Myapp();
  }
}

class _Myapp extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Chedo On Fire",
      home: HomePage(),
    );
  }
}
